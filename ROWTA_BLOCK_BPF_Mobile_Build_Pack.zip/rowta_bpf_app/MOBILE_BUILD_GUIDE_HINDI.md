# ROWTA BLOCK BPF — मोबाइल से APK बनाने की गाइड

यह प्रोजेक्ट अभी शुरुआती Flutter prototype है। यह workflow GitHub के cloud runner पर Android APK बनाता है; आपके फोन पर Flutter/Android Studio इंस्टॉल करने की जरूरत नहीं है।

## मोबाइल से APK बनाने के चरण

1. ZIP को Extract करें। `rowta_bpf_app` फोल्डर के अंदर की सभी फाइलें (जैसे `lib`, `assets`, `pubspec.yaml`, `README.md` और `.github`) GitHub repository के root में अपलोड करें। ZIP फाइल को repository में अकेले अपलोड न करें।
2. मोबाइल ब्राउज़र में https://github.com खोलें और साइन इन/साइन अप करें।
3. `New repository` चुनें, नाम `rowta-block-bpf-app` रखें, `Public` या `Private` चुनें और repository बनाएँ।
4. repository में `Add file` → `Upload files` से Extract किए गए प्रोजेक्ट की फाइलें/फोल्डर अपलोड करके `Commit changes` दबाएँ। ध्यान दें कि `.github/workflows/android-apk.yml` भी अपलोड होना चाहिए।
5. repository के `Actions` टैब में `Build ROWTA BLOCK BPF APK` workflow खोलें। `Run workflow` दबाएँ। पहली बार push पर भी workflow अपने-आप चल सकता है।
6. Build पूरा होने पर उसी workflow run के नीचे `Artifacts` में `ROWTA-BLOCK-BPF-APK` डाउनलोड करें। ZIP खोलकर `app-release.apk` निकालें।
7. APK पर टैप करके इंस्टॉल करें। Android पूछे तो केवल GitHub से डाउनलोड की गई अपनी build के लिए browser/files app को install permission दें।

## जरूरी स्थिति

- यह APK केवल मौजूदा starter prototype होगा। Members, committees, notices, events, gallery, complaints और admin वाले बटन अभी placeholder screens हैं।
- OTP login, Firebase/online database, role permissions, admin approval, privacy/security rules और production testing अभी लागू नहीं हैं।
- वास्तविक सदस्यों का निजी डेटा इस prototype में न डालें। इसे सार्वजनिक/आधिकारिक इस्तेमाल में तभी लाएँ जब backend, सुरक्षा और परीक्षण पूरे हों।
- GitHub account बनाना और repository में फाइलें अपलोड करना आपके मोबाइल पर करना होगा; build GitHub के cloud server पर होगा।

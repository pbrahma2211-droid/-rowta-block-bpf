import 'package:flutter/material.dart';

void main() => runApp(const RowtaBpfApp());

class RowtaBpfApp extends StatefulWidget {
  const RowtaBpfApp({super.key});
  @override
  State<RowtaBpfApp> createState() => _RowtaBpfAppState();
}

class _RowtaBpfAppState extends State<RowtaBpfApp> {
  String language = 'en';
  final Map<String, Map<String, String>> words = {
    'en': {'welcome':'Welcome','members':'Members','committees':'Committees','notices':'Notices','events':'Meetings & Events','gallery':'Photo Gallery','complaints':'Complaints','documents':'Documents','admin':'Admin Login','subtitle':'Bodoland People’s Front · Rowta Block','demo':'Starter preview — connect the secure database before live use.'},
    'hi': {'welcome':'स्वागत है','members':'सदस्य','committees':'समितियाँ','notices':'सूचनाएँ','events':'बैठक और कार्यक्रम','gallery':'फोटो गैलरी','complaints':'शिकायतें','documents':'दस्तावेज़','admin':'एडमिन लॉगिन','subtitle':'बोडोलैंड पीपल्स फ्रंट · रौता ब्लॉक','demo':'प्रारंभिक नमूना — वास्तविक उपयोग से पहले सुरक्षित डेटाबेस जोड़ना होगा।'},
    'as': {'welcome':'স্বাগতম','members':'সদস্য','committees':'সমিতিসমূহ','notices':'জাননী','events':'সভা আৰু কাৰ্যসূচী','gallery':'ফটো গেলেৰী','complaints':'অভিযোগ','documents':'নথিপত্ৰ','admin':'এডমিন লগইন','subtitle':'বড়োলেণ্ড পিপলছ ফ্ৰণ্ট · ৰৌতা ব্লক','demo':'প্ৰাথমিক নমুনা — বাস্তৱ ব্যৱহাৰৰ আগতে সুৰক্ষিত ডাটাবেছ সংযোগ কৰিব লাগিব।'},
  };
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ROWTA BLOCK BPF',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF08752B)), useMaterial3: true),
    home: HomePage(language: language, words: words, onLanguage: (v) => setState(() => language = v)),
  );
}

class HomePage extends StatelessWidget {
  final String language;
  final Map<String, Map<String, String>> words;
  final ValueChanged<String> onLanguage;
  const HomePage({super.key, required this.language, required this.words, required this.onLanguage});
  @override
  Widget build(BuildContext context) {
    final t = words[language]!;
    final entries = [
      (Icons.people_alt_outlined, t['members']!, 'Member registration and directory'),
      (Icons.account_tree_outlined, t['committees']!, 'Block and primary committee records'),
      (Icons.campaign_outlined, t['notices']!, 'Official notices and circulars'),
      (Icons.event_available_outlined, t['events']!, 'Meeting dates, time and venue'),
      (Icons.photo_library_outlined, t['gallery']!, 'Programme photographs and videos'),
      (Icons.feedback_outlined, t['complaints']!, 'Submit and track a complaint'),
      (Icons.folder_open_outlined, t['documents']!, 'Party documents and forms'),
      (Icons.admin_panel_settings_outlined, t['admin']!, 'Restricted administrator access'),
    ];
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7F5),
      appBar: AppBar(title: const Text('ROWTA BLOCK BPF', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .3)), actions: [
        Padding(padding: const EdgeInsets.only(right: 10), child: DropdownButton<String>(value: language, underline: const SizedBox(), items: const [DropdownMenuItem(value:'as',child:Text('অসমীয়া')),DropdownMenuItem(value:'hi',child:Text('हिंदी')),DropdownMenuItem(value:'en',child:Text('English'))], onChanged: (v) { if (v != null) onLanguage(v); })),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        ClipRRect(borderRadius: BorderRadius.circular(20), child: Image.asset('assets/bpf_flag.png', height: 112, fit: BoxFit.cover)),
        const SizedBox(height: 14),
        Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(60), child: Image.asset('assets/rowta_bpf_logo.jpg', width: 88, height: 88, fit: BoxFit.cover)),
          const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t['welcome']!, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 4), const Text('ROWTA BLOCK BPF', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF08752B))), Text(t['subtitle']!, style: Theme.of(context).textTheme.bodySmall)]))
        ]))),
        const SizedBox(height: 10),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: entries.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.35), itemBuilder: (context, i) {
          final e = entries[i];
          return InkWell(borderRadius: BorderRadius.circular(16), onTap: () => _openFeature(context, e.$2, e.$3), child: Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Icon(e.$1, color: const Color(0xFF08752B), size: 29), const SizedBox(height: 9), Text(e.$2, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 3), Text(e.$3, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall)]))));
        }),
        const SizedBox(height: 14),
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFE8F2E9), borderRadius: BorderRadius.circular(12)), child: Text(t['demo']!, style: const TextStyle(fontSize: 12, color: Color(0xFF34523B)))),
      ]),
    );
  }
  void _openFeature(BuildContext context, String title, String description) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => FeaturePage(title: title, description: description)));
  }
}

class FeaturePage extends StatelessWidget {
  final String title, description;
  const FeaturePage({super.key, required this.title, required this.description});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title)), body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.construction_outlined, size: 54, color: Color(0xFF08752B)), const SizedBox(height: 16), Text(title, style: Theme.of(context).textTheme.headlineSmall), const SizedBox(height: 8), Text(description, textAlign: TextAlign.center), const SizedBox(height: 16), const Text('This module is part of the starter build. Database, authentication and admin permissions must be configured before publishing.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54))]))));
}

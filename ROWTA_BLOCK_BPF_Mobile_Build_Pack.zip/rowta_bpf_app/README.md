# ROWTA BLOCK BPF — Android starter project

This is a Flutter starter project for the Rowta Block BPF app. It includes:
- App home screen and the supplied BPF flag artwork
- Circular BPF logo artwork with the lower label changed to ROWTA
- Assamese, Hindi and English interface labels
- Navigation placeholders for Members, Committees, Notices, Events, Gallery, Complaints, Documents and Admin

## Important status
This is a **starter prototype**, not a production-ready app and not an APK. The feature pages are placeholders. No real member data is collected or stored, and no OTP authentication or online database is connected yet.

## Build locally
1. Install Flutter SDK and Android Studio (Android SDK + platform tools).
2. From this folder run `flutter pub get`.
3. Run `flutter run` to test on an Android phone/emulator.
4. When backend setup and testing are complete, run `flutter build apk --release`.

## Production work still required
- Create a Firebase project and configure Android app ID/package name.
- Add Firebase Authentication phone OTP, with abuse protection and consent.
- Add Firestore collections and security rules for users, committees, notices, events, complaints and documents.
- Implement role-based access: Super Admin, Committee Admin and Member.
- Add admin approval workflow, audit logs, privacy policy, backup and data deletion process.
- Test on real Android devices and sign the release build.

Never place Firebase service-account secrets or private admin credentials in the app source code.
